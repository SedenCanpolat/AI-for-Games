package chapter2;

public enum AccelerationType {
    Kinematic,
    Dynamic;
}
