package chapter2;

public enum OrientationType {
    Explicit,
    VelocityBased;
}
