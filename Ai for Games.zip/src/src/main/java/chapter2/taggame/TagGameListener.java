package chapter2.taggame;

public interface TagGameListener {
    void tagChanged(TagPlayer player);
    void warmupFinished();

}
