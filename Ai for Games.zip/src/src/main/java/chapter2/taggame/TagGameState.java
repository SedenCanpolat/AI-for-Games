package chapter2.taggame;

public enum TagGameState {
    InPlay , WarmUp;
}
